from pypylon import pylon
import cv2

def capture_image(image_name,exp,gain_value):

    tl_factory = pylon.TlFactory.GetInstance()

    # 獲取所有已連接的相機
    devices = tl_factory.EnumerateDevices()

    if len(devices) == 0:
        print("未檢測到相機")
        return

    # 選擇第一個相機
    camera = pylon.InstantCamera(tl_factory.CreateDevice(devices[0]))

    # 開啟相機
    camera.Open()

    try:
        # 設置相機參數
        camera.PixelFormat = "Mono8"  # 可以根據需要選擇不同的像素格式
        camera.ExposureTime = exp  # 曝光時間（微秒）
        if camera.GainRaw.Min < gain_value < camera.GainRaw.Max:
            camera.GainRaw.Value = gain_value
        else:
            print("增益值超出範圍")
        
        # 拍攝一張照片
        camera.StartGrabbing(pylon.GrabStrategy_LatestImageOnly)
        grab_result = camera.RetrieveResult(5000, pylon.TimeoutHandling_ThrowException)

        if grab_result.GrabSucceeded():
            # 將照片轉換為NumPy數組
            image = grab_result.Array

            cv2.imwrite(image_name,image)

            # 顯示照片寬度和高度
            print("Image width:", image.shape[1])
            print("Image height:", image.shape[0])

        grab_result.Release()
    finally:
        # 關閉相機
        camera.Close()


# 執行拍照函數
if __name__=='__main__':
    capture_image("mason_basler.png",666666,0)